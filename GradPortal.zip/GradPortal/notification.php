<?php
// notification.php

require 'core/init.php';

$company_id = $user->user_id;

$notifications = $getFromT->getNotifications($company_id);

if ($notifications) {
    foreach ($notifications as $notification) {
        echo "<p>New application from: {$notification->screenName} for job: {$notification->job_title}</p>";
    }
} else {
    echo "No new notifications.";
}
?>
