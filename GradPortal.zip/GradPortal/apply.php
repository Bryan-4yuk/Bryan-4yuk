<?php
include 'core/init.php'; // Include your database connection
require_once 'core/classes/tweet.php'; // Use require_once to avoid redeclaration

if (isset($_POST['job_id']) && isset($_POST['company_id'])) {
    $job_id = $_POST['job_id'];
    $company_id = $_POST['company_id'];
    $user_id = $_SESSION['user_id'];

    // Check if already applied
    if ($getFromU->hasApplied($user_id, $job_id)) {
        echo 'already_applied';
        exit; // Exit to prevent further execution
    }

    // Insert application into the database
    $getFromU->create('applications', array(
        'job_id' => $job_id,
        'graduate_id' => $user_id, // Use graduate_id instead of user_id
        'company_id' => $company_id,
        'applied_at' => date('Y-m-d H:i:s')
    ));

    // Send a clean success response
    echo 'success';
    exit; // Exit to prevent further output
}
?>
