<?php 
include 'core/init.php';

// Check if user is logged in
if($getFromU->loggedIn() === false){
    header('Location: index.php');
    exit(); // Stop further execution after redirect
}

$user_id = $_SESSION['user_id'];
$user = $getFromU->userData($user_id);

if(isset($_POST['screenName'])){
    if(!empty($_POST['screenName'])){
        // Other form data
        $screenName  = $getFromU->checkInput($_POST['screenName']);
        $profileBio  = $getFromU->checkInput($_POST['bio']);
        $country     = $getFromU->checkInput($_POST['country']);
        $website     = $getFromU->checkInput($_POST['website']);
        
        // Check if a CV file is uploaded
        $cvFile = isset($_FILES['cvFile']) && !empty($_FILES['cvFile']['name']) ? $_FILES['cvFile'] : null;

        // Debugging - Check if cvFile is detected
        var_dump($cvFile); // Add this line for testing
        
        if(strlen($screenName) > 20){
            $error  = "Name must be between 6-20 characters";
        } else if(strlen($profileBio) > 120){
            $error = "Description is too long";
        } else if(strlen($country) > 80){
            $error = "Country name is too long";
        } else {
            // Update user info in the database
            $getFromU->updateUserInfo($user_id, array(
                'screenName' => $screenName, 
                'bio' => $profileBio, 
                'country' => $country, 
                'website' => $website
            ), $cvFile);
            
            header('Location: profile.php?username='.$user->username);
            exit();
        }
    } else {
        $error = "Name field can't be blank";
    }
}


// Handle file uploads (CV, profile image, profile cover)
if(isset($_FILES['cvFile'])){
    if(!empty($_FILES['cvFile']['name'])){
        // Ensure you handle file upload within the function
        $getFromU->uploadCV($user_id, $_FILES['cvFile']);
        header('Location: profileEdit.php');
        exit(); // Stop further execution after redirect
    }
}

if(isset($_FILES['profileImage'])){
    if(!empty($_FILES['profileImage']['name'])){
        $getFromU->updateProfileImage($user_id, $_FILES['profileImage']);
        header('Location: profileEdit.php');
        exit(); // Stop further execution after redirect
    }
}

if(isset($_FILES['profileCover'])){
    if(!empty($_FILES['profileCover']['name'])){
        $getFromU->updateProfileCover($user_id, $_FILES['profileCover']);
        header('Location: profileEdit.php');
        exit(); // Stop further execution after redirect
    }
}

// Display any errors
if(isset($error)){
    echo '<div class="error">'.$error.'</div>';
}
?>

<!doctype html>
<html>

<head>

    <title>Edit Profile - GC</title>
    <meta charset="UTF-8" />
    
    <link rel="shortcut icon" type="image/x-icon" href="./assets/images/bird.svg">
    
    	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css"/>
    <link rel='stylesheet' href='<?php echo BASE_URL; ?>assets/css/font-awesome.css' />
    <link rel='stylesheet' href='<?php echo BASE_URL; ?>assets/css/bootstrap.css' />
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style-complete.css" />
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css" />
    <script src="<?php echo BASE_URL; ?>assets/js/jquery-3.1.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.js" integrity="sha256-16cdPddA6VdVInumRGo6IbivbERE8p7CQR3HzTBuELA=" crossorigin="anonymous"></script>
</head>

<body>
<header class="grad-header">
            <div class="header-left">
            <h1>Grad Career Portal</h1>
            <a href="<?php echo BASE_URL; ?>home.php"></a>
            </div>
            <div class="header-right">
                <ul class="header-icons">
                    <li>
                        <a href="<?php echo BASE_URL;?>i/notifications">
                            <i class="fa fa-bell" aria-hidden="true"></i>
                        </a>
                    </li>
                    <li id='messagePopup'>
                        <a>
                            <i class="fa fa-envelope" aria-hidden='true'></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL; ?><?php echo "profile.php?username=".$user->username.""; ?>">
                            <i class="fa fa-user"></i>
                        </a>
                    </li>
                    <li>
                        <a href='<?php echo BASE_URL; ?>settings/account'>
                            <i class="fa fa-cog"></i>
                        </a>
                    </li>
                </ul>
                <img src="assets/images/TY.png" alt="Custom Image" class="header-logo">
            </div>
        </header>
        

    <div class="grid-container">

        <?php require 'left-sidebar.php' ?>


        <div class="main">

            <p class="page_title mb-0"><i class="fa fa-pencil-square-o mr-4" style="color:#dc2e2e;"></i>Edit Profile</p>

            <div class='profile-box'>
                <div class='profile-cover mt-0'>
                    <!-- PROFILE-IMAGE -->
                    <img src="<?php echo BASE_URL.$user->profileCover; ?>" />
                    <div class="img-upload-button-wrap">
                        <div class="img-upload-button1">
                            <label for="cover-upload-btn">
                                <i class="fa fa-camera" aria-hidden="true"></i>
                            </label>
                            <span class="span-text1">
                                Change your profile photo
                            </span>
                            <input id="cover-upload-btn" type="checkbox" />
                            <div class="img-upload-menu1">
                                <span class="img-upload-arrow"></span>
                                <form method="post" enctype="multipart/form-data">
                                    <ul>
                                        <li>
                                            <label for="file-up">
                                                Upload photo
                                            </label>
                                            <input type="file" onchange="this.form.submit();" name="profileCover" id="file-up" />
                                        </li>
                                        <li>
                                            <label for="cover-upload-btn">
                                                Cancel
                                            </label>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='profile-body'>
                    <div class="profile-header">
                        <div class="profile-image">
                            <img src="<?php echo BASE_URL.$user->profileImage; ?>" />
                            <div class="img-upload-button-wrap1">
                                <div class="img-upload-button">
                                    <label for="img-upload-btn">
                                        <i class="fa fa-camera" aria-hidden="true"></i>
                                    </label>
                                    <input id="img-upload-btn" type="checkbox" />
                                    <div class="img-upload-menu">
                                        <span class="img-upload-arrow"></span>
                                        <form method="post" enctype="multipart/form-data">
                                            <ul>
                                                <li>
                                                    <label for="profileImage">
                                                        Upload photo
                                                    </label>
                                                    <input id="profileImage" type="file" onchange="this.form.submit();" name="profileImage" />

                                                </li>
                                                <li><a href="#">Remove</a></li>
                                                <li>
                                                    <label for="img-upload-btn">
                                                        Cancel
                                                    </label>
                                                </li>
                                            </ul>
                                        </form>
                                    </div>
                                </div>
                                <!-- img upload end-->
                            </div>
                        </div>
                    </div>
                    <div class="profile-text">
                    <form id="editForm" method="post" enctype="multipart/form-data" autocomplete="off">
                        <!-- Name -->
                        <div class="form-group">
                            <label class="ml-1">Name</label>
                            <input type="text" class="form-control" name="screenName" value="<?php echo $user->screenName;?>" />
                        </div>
                        
                        <!-- Country -->
                        <div class="form-group">
                            <label class="ml-1">Location</label>
                            <input class="form-control" id="cn" type="text" name="country" placeholder="Country" value="<?php echo $user->country;?>" />
                        </div>

                        <!-- Website -->
                        <div class="form-group">
                            <label class="ml-1">Website</label>
                            <input class="form-control" type="text" name="website" placeholder="Website" value="<?php echo $user->website;?>" />
                        </div>

                        <!-- Bio -->
                        <div class="form-group">
                            <label class="ml-1">Bio</label>
                            <textarea class="status form-control" name="bio"><?php echo $user->bio;?></textarea>
                        </div>
                        
                        <!-- Upload CV -->
                        <div class="form-group">
                            <label class="ml-1">Upload CV</label>
                            <input type="file" class="form-control-file" name="cvFile" accept=".pdf, .txt, .doc, .docx" />
                        </div>

                        <!-- Save Button -->
                        <button type="submit" class="new-btn">Save Profile</button>
                    </form>
                        <script type="text/javascript">
                            $('#save').click(function() {
                                $('#editForm').submit();
                            });

                        </script>

                    </div>
                </div>
            </div>
            
        </div>
        <?php require 'right-sidebar.php' ?>



        <script type='text/javascript' src='<?php echo BASE_URL;?>assets/js/search.js'></script>
        <script type='text/javascript' src='<?php echo BASE_URL;?>assets/js/hashtag.js'></script>
        <script type='text/javascript' src='<?php echo BASE_URL;?>assets/js/follow.js'></script>
        <script src='<?php echo BASE_URL;?>assets/js/jquery-3.1.1.min.js'></script>
        <script src='<?php echo BASE_URL;?>assets/js/popper.min.js'></script>
        <script src='<?php echo BASE_URL;?>assets/js/bootstrap.min.js'></script>
        <script type='text/javascript' src='<?php echo BASE_URL;?>assets/js/comment.js'></script>
        <script type='text/javascript' src='<?php echo BASE_URL;?>assets/js/fetch.js'></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/popuptweets.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/delete.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/popupForm.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/retweet.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/like.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/hashtag.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/search.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/follow.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/messages.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/notification.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/postMessage.js"></script>

</body>
</html>
