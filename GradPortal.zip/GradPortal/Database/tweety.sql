-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2024 at 03:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tweety`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `application_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `graduate_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`application_id`, `job_id`, `graduate_id`, `company_id`, `applied_at`) VALUES
(1, 3, 12, 14, '2024-08-31 12:09:08'),
(2, 4, 12, 14, '2024-08-31 12:09:18'),
(3, 2, 12, 11, '2024-08-31 12:09:45'),
(4, 7, 13, 11, '2024-09-01 10:46:19'),
(5, 6, 13, 11, '2024-09-01 10:46:28'),
(6, 5, 13, 16, '2024-09-01 11:00:32'),
(7, 7, 12, 11, '2024-09-01 16:21:13'),
(8, 7, 18, 11, '2024-09-01 20:40:55'),
(9, 5, 12, 16, '2024-09-02 19:06:36'),
(10, 8, 18, 11, '2024-09-07 13:02:01'),
(11, 9, 18, 24, '2024-09-07 13:02:57'),
(12, 10, 18, 11, '2024-09-07 20:01:52'),
(13, 11, 18, 22, '2024-09-07 21:27:26'),
(14, 14, 19, 16, '2024-09-08 09:44:27'),
(15, 5, 19, 16, '2024-09-08 09:45:10'),
(16, 9, 31, 24, '2024-09-08 12:47:04'),
(17, 9, 32, 24, '2024-09-08 12:59:03');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `comment` varchar(140) NOT NULL,
  `commentOn` int(11) NOT NULL,
  `commentBy` int(11) NOT NULL,
  `commentAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

CREATE TABLE `follow` (
  `followID` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `followOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `friendships`
--

CREATE TABLE `friendships` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` enum('pending','accepted','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friendships`
--

INSERT INTO `friendships` (`id`, `user_id`, `friend_id`, `status`, `created_at`) VALUES
(1, 18, 12, 'accepted', '2024-09-04 21:03:31'),
(2, 18, 15, 'pending', '2024-09-07 09:39:59'),
(3, 21, 18, 'accepted', '2024-09-07 10:59:05'),
(4, 18, 13, 'accepted', '2024-09-07 12:03:53'),
(5, 18, 11, 'pending', '2024-09-07 19:04:29'),
(6, 19, 18, 'accepted', '2024-09-07 19:05:22'),
(7, 28, 12, 'pending', '2024-09-07 20:20:36'),
(8, 28, 18, 'accepted', '2024-09-07 20:20:43'),
(9, 19, 12, 'pending', '2024-09-08 08:47:14'),
(10, 29, 19, 'pending', '2024-09-08 08:57:16'),
(11, 21, 19, 'pending', '2024-09-08 09:00:14'),
(12, 31, 18, 'accepted', '2024-09-08 11:48:00');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `job_description` text NOT NULL,
  `skills_required` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `user_id`, `job_title`, `job_description`, `skills_required`, `created_at`) VALUES
(2, 11, 'Vulnerabity Tester', 'Tester probes for and exploits security vulnerabilities in web-based applications, networks and systems. Penetration Tests are designed to achieve a specific, attacker-simulated goal and should be requested by customers who are already at their desired security posture.', 'cyber security - Network administration', '2024-08-30 10:06:14'),
(3, 14, 'Accountant', 'Accountant to prepare and examine financial records, identify potential areas of opportunity and risk, and provide solutions for businesses and individuals. They ensure that financial records are accurate, that financial and data risks are evaluated, and that taxes are paid properly.', 'Time management - Analytical thinking - Problem-solving skills.', '2024-08-30 15:46:04'),
(4, 14, 'Cloud Engineer', 'To builds and maintains cloud infrastructure. The engineers can have more specific roles that include cloud architecting (designing cloud solutions for organisations), development (coding for the cloud), and administration (working with cloud networks).', 'Proficiency in Programming Languages - Understanding Software and Database Concepts- Networking Skills', '2024-08-30 15:47:56'),
(5, 16, 'Systems Analyst', 'Evaluates and improves IT systems to align with business objectives, ensuring optimal performance and efficiency. Works with stakeholders to gather requirements and translate them into technical specifications. Analyzes system issues and develops solutions.', 'Strong analytical skills - knowledge of database management (SQL) - excellent communication abilities.', '2024-09-01 10:13:55'),
(6, 11, 'Front-End Developer', 'Creates visually appealing and user-friendly interfaces for web applications, emphasizing responsive design. Utilizes HTML, CSS, and JavaScript to build dynamic user experiences. Collaborates with designers to implement UI/UX best practices.', 'Proficiency in HTML - CSS - JavaScript', '2024-09-01 10:15:29'),
(7, 11, 'Software Quality Assurance (QA) Engineer', 'Ensures the quality and functionality of software products through rigorous testing. Develops test plans, executes tests, and identifies issues for resolution. Collaborates with development teams to improve product quality.', 'Knowledge of testing methodologies - experience with testing tools (Selenium, JUnit),', '2024-09-01 10:16:46'),
(8, 11, 'New Job', 'jod description', 'Html - php', '2024-09-02 19:00:54'),
(9, 24, 'Vulnerabity Tester', 'asdfghjklasdfghjk', 'html- css', '2024-09-07 12:54:17'),
(10, 11, 'Cloud Engineer', 'data bases online', 'cloud', '2024-09-07 20:01:33'),
(11, 22, 'Demon Slayer', 'Killing some demons', 'Css - breathing', '2024-09-07 21:25:55'),
(12, 24, 'Systems Administrator', 'Systems Administrators manage and maintain an organization’s IT infrastructure, ensuring system performance, security, and availability. They troubleshoot issues, perform system updates, and implement security protocols to protect data and resources.', 'Linux - Windows', '2024-09-08 09:08:22'),
(13, 24, 'Front-End Developer', 'Front-End Developers focus on creating the visual and interactive aspects of web applications. They transform design concepts into responsive user interfaces using HTML, CSS, and JavaScript, ensuring a seamless user experience across devices.', 'HTML- CSS - JavaScript', '2024-09-08 09:09:25'),
(14, 16, 'UX/UI Designer', 'UX/UI Designers create intuitive and engaging user interfaces for software applications. They conduct user research, develop wireframes and prototypes, and collaborate with developers to ensure a smooth user experience.', 'Adobe XD - Figma - Sketch', '2024-09-08 09:10:34');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `likeID` int(11) NOT NULL,
  `likeBy` int(11) NOT NULL,
  `likeOn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`likeID`, `likeBy`, `likeOn`) VALUES
(1, 5, 3);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `sender_id`, `receiver_id`, `message`, `created_at`) VALUES
(1, 12, 18, 'hey there', '2024-09-06 08:39:46'),
(2, 18, 12, 'yeah whatsup', '2024-09-06 08:41:09'),
(3, 12, 18, '////', '2024-09-06 08:47:10'),
(4, 12, 18, 'hjk', '2024-09-06 08:51:56'),
(5, 12, 18, 'yuuii', '2024-09-06 08:56:36'),
(6, 18, 12, 'kk', '2024-09-07 09:42:02'),
(7, 18, 12, 'fkfkd', '2024-09-07 09:42:07'),
(8, 18, 12, 'yeah whatsup', '2024-09-07 09:44:59'),
(9, 18, 12, 'dww', '2024-09-07 09:45:05'),
(10, 18, 12, 'kkk', '2024-09-07 10:06:21'),
(11, 12, 18, 'ddd', '2024-09-07 10:06:36'),
(12, 18, 13, 'hey there', '2024-09-07 13:05:26'),
(13, 13, 18, 'yu', '2024-09-07 13:05:38'),
(14, 18, 19, 'hey there', '2024-09-07 20:06:14'),
(15, 19, 18, 'yeah whatsup', '2024-09-07 20:06:42'),
(16, 28, 18, 'hey', '2024-09-07 21:22:38'),
(17, 18, 28, 'hey there', '2024-09-07 21:22:54'),
(18, 18, 19, 'Got any plans for the weekend?', '2024-09-08 10:29:19'),
(19, 19, 18, 'Not much yet. Just thinking of relaxing. You?', '2024-09-08 10:29:40'),
(20, 18, 19, 'I was thinking we could go hiking if the weather\'s nice!', '2024-09-08 10:29:53'),
(21, 19, 18, 'That sounds awesome! Do you have a specific trail in mind?', '2024-09-08 10:30:07'),
(22, 18, 19, 'How about the one at Green Valley? It’s supposed to have great views! 📸', '2024-09-08 10:30:20'),
(23, 19, 18, 'Perfect! What time do you want to head out?', '2024-09-08 10:30:31'),
(24, 18, 19, 'How about we meet at 8 AM? That way we can beat the heat.👌👌', '2024-09-08 10:30:52'),
(25, 19, 18, 'Sounds good to me! Do we need to bring anything special?', '2024-09-08 10:31:05'),
(26, 18, 19, 'Great! Can’t wait! It’ll be nice to get some fresh air. 🌞', '2024-09-08 10:31:16'),
(27, 31, 18, 'hey there', '2024-09-08 12:49:04');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trends`
--

CREATE TABLE `trends` (
  `trendID` int(11) NOT NULL,
  `hashtag` varchar(140) NOT NULL,
  `createdOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trends`
--

INSERT INTO `trends` (`trendID`, `hashtag`, `createdOn`) VALUES
(1, '100daysofcode', '2021-04-28 13:03:19'),
(6, 'GoogleIO', '2021-04-28 13:13:22'),
(8, 'IndiaFacultySummit', '2021-04-28 13:14:49'),
(10, 'tweets', '2021-04-28 13:17:45'),
(17, '039', '2024-08-28 16:36:34');

-- --------------------------------------------------------

--
-- Table structure for table `tweets`
--

CREATE TABLE `tweets` (
  `tweetID` int(11) NOT NULL,
  `status` varchar(1000) NOT NULL,
  `tweetBy` int(11) NOT NULL,
  `retweetID` int(11) NOT NULL,
  `retweetBy` int(11) NOT NULL,
  `tweetImage` varchar(255) DEFAULT NULL,
  `likesCount` int(11) NOT NULL,
  `retweetCount` int(11) NOT NULL,
  `postedOn` datetime NOT NULL,
  `retweetMsg` varchar(140) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tweets`
--

INSERT INTO `tweets` (`tweetID`, `status`, `tweetBy`, `retweetID`, `retweetBy`, `tweetImage`, `likesCount`, `retweetCount`, `postedOn`, `retweetMsg`) VALUES
(15, 'The 10 Key Spring/Summer 2024 Fashion Trends To Know Now\r\nThe spring/summer 2024 fashion trends piled up, designers waited nervously to see if their collections would be eclipsed by a spontaneous digital drop.', 13, 0, 0, '', 0, 0, '2024-08-30 16:42:20', ''),
(16, 'Time series analysis and short-term forecasting of monkeypox outbreak trends in the 10 major affected countries\r\nConsidering the rapidly spreading monkeypox outbreak, WHO has declared a global health emergency. Still in the category of being endemic,...\r\n.2 Jan 2024', 13, 0, 0, '', 0, 0, '2024-08-30 16:42:47', ''),
(19, 'Test post article with image', 12, 0, 0, 'uploads/tweetImages/66d429d49ab734.82371400.jpg', 0, 0, '2024-09-01 09:46:12', ''),
(24, 'Have You Witnessed an Act of Kindness While Traveling? Share It With Us.\r\nWe&#039;re asking travelers to share the most memorable random acts of kindness they&#039;ve seen or experienced during their trips near and far.\r\n.25 Dec 2023', 15, 0, 0, 'uploads/tweetImages/66d42c72db6c88.06277760.jpg', 0, 0, '2024-09-01 09:57:22', ''),
(25, '&#039;Terror attack&#039; in Germany: Knifeman leaves several dead after stabbing random passersby in the neck at divers\r\nA knifeman has left several people dead after stabbing random passersby in the neck in a horrific &#039;terror attack&#039; at a diversity festival in...', 13, 0, 0, 'uploads/tweetImages/66d42f5aa2ded6.57109258.jpg', 0, 0, '2024-09-01 10:09:46', ''),
(26, 'Stochastic modeling of injection induced seismicity based on the continuous time random walk model\r\nThe spatiotemporal evolution of earthquakes induced by fluid injections into the subsurface can be erratic owing to the complexity of the...', 13, 0, 0, 'uploads/tweetImages/66d43b1de91e84.13668010.jpg', 0, 0, '2024-09-01 10:59:57', ''),
(27, 'A journey into Wikipedia&#039;s depths by way of the “Random Article” feature on its front page and left navigation.', 12, 0, 0, 'uploads/tweetImages/66d440d0c855a5.19649548.jpg', 0, 0, '2024-09-01 11:24:16', ''),
(28, 'Lets meet tomorrow', 18, 0, 0, '', 0, 0, '2024-09-01 20:40:46', ''),
(34, 'The lesson is that you can’t always get what you want.', 19, 0, 0, 'uploads/tweetImages/66dd5e1302bf21.63131551.jpg', 0, 0, '2024-09-08 09:19:31', ''),
(35, 'Power comes in response to a need, not a desire. You have to create that need.', 12, 0, 0, 'uploads/tweetImages/66dd5e4cbea6a5.56185589.jpg', 0, 0, '2024-09-08 09:20:28', ''),
(36, 'If you don’t take risks, you can’t create a future.', 29, 0, 0, 'uploads/tweetImages/66dd5eaa6505a9.60625796.jpg', 0, 0, '2024-09-08 09:22:02', ''),
(37, 'hhfkd', 31, 0, 0, '', 0, 0, '2024-09-08 12:46:23', ''),
(38, 'post article', 32, 0, 0, 'uploads/tweetImages/66dd9157e9dd91.82686664.jpg', 0, 0, '2024-09-08 12:58:15', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `screenName` varchar(40) NOT NULL,
  `profileImage` varchar(255) NOT NULL,
  `profileCover` varchar(255) NOT NULL,
  `following` int(11) NOT NULL,
  `followers` int(11) NOT NULL,
  `bio` varchar(140) NOT NULL,
  `country` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `usertype` enum('Graduate','Company') NOT NULL,
  `cv` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `screenName`, `profileImage`, `profileCover`, `following`, `followers`, `bio`, `country`, `website`, `usertype`, `cv`) VALUES
(11, 'HelpingHand2334', 'test19@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Helping Hands', 'users/8f32e6c618e8403e021534b4bc1119c2.jpg', 'users/2b7103aa6ad0ce91d20f6c86ead4fb44.jpg', 0, 0, 'sdfghjkdfghjkl', 'Cameroon', 'helpinghands.com', 'Company', NULL),
(12, 'Lebao26789', 'bryan@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Bryan', 'users/1f476ba1a784f8750bacb054d41b06f7.jpg', 'users/2c71f7fc1a57010f17beb9d1841060e1.jpg', 0, 0, '', '', '', 'Graduate', 'CVs/66dbf39d5d1fe5.18155968.docx'),
(13, 'MarkKC4578', 'mark@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Mark Testla', 'users/po image.jpg', 'users/co image.jpg', 0, 0, '', '', '', 'Graduate', NULL),
(14, 'Oriflame2312', 'ori@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Oriflame Cosmetics', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Company', NULL),
(15, 'HomeboyJonny673', 'Jonathan@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Jonny', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(16, '3rdCompany090', 'test20@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', '3rdCompany', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Company', NULL),
(18, 'LK12343', 'lucy@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Lucy K', 'users/ffbbf8a8095106ab162834abcf5efc13.jpg', 'users/po image.jpg', 0, 0, 'know pain', 'Senegal', 'dovv.com', 'Graduate', 'CVs/66dcb5f126ff50.03316508.docx'),
(19, 'Tinda7890', 'tina@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'SweetTina', 'users/894dd1201940a3c5b5e6a344e546191b.jpg', 'users/2c71f7fc1a57010f17beb9d1841060e1.jpg', 0, 0, 'A new legacy for Us', 'Senegal', 'le_bao.com', 'Graduate', 'CVs/66dca4d4d229a6.02505679.docx'),
(20, 'DOVcmr237', 'dovv@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Dov', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Company', NULL),
(21, 'Chris78930', 'chris@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'CHrisking', 'users/992b289cd0930694af06dac248d9bd56.jpg', 'users/ede207095a48f0b2ccc60fe9916fbb4e.jpg', 0, 0, 'The lesson is that you can’t always get what you want.', 'cameroon', 'noe.com', 'Graduate', NULL),
(22, 'Shalom4938409', 'shalom@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Shalom Beauty', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Company', NULL),
(23, 'Newtest547', 'news@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'new user', 'users/2b7103aa6ad0ce91d20f6c86ead4fb44.jpg', 'users/2c71f7fc1a57010f17beb9d1841060e1.jpg', 0, 0, '', '', '', 'Graduate', NULL),
(24, 'Kwazaki', 'test3@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Test 3', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Company', NULL),
(25, 'kawazaki367', 'uio@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Kawazaki', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(26, 'Ntub2536', 'therese@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Therese', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(27, '', 'atem@kk', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Atem', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(28, 'Ton456', 'tin@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Tonton', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(29, 'Timberlake34', 'just@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Justin', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(30, 'Evan56u7', 'Evan@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Evan', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL),
(31, 'Chris898', 'obinachris@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Chris koffi', 'users/5efd7549fc7a371332156939e7e65e30.jpg', 'users/2c71f7fc1a57010f17beb9d1841060e1.jpg', 0, 0, 'asdfghjk', 'Cameroon', 'obin.com', 'Graduate', NULL),
(32, 'Tube463', 'therese56@gmail.com', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Therese Ayuk', 'assets/images/defaultProfileImage.png', 'assets/images/defaultCoverImage.png', 0, 0, '', '', '', 'Graduate', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`application_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `follow`
--
ALTER TABLE `follow`
  ADD PRIMARY KEY (`followID`);

--
-- Indexes for table `friendships`
--
ALTER TABLE `friendships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`likeID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `trends`
--
ALTER TABLE `trends`
  ADD PRIMARY KEY (`trendID`),
  ADD UNIQUE KEY `createdOn` (`createdOn`);

--
-- Indexes for table `tweets`
--
ALTER TABLE `tweets`
  ADD PRIMARY KEY (`tweetID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `follow`
--
ALTER TABLE `follow`
  MODIFY `followID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `friendships`
--
ALTER TABLE `friendships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `likeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trends`
--
ALTER TABLE `trends`
  MODIFY `trendID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tweets`
--
ALTER TABLE `tweets`
  MODIFY `tweetID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
